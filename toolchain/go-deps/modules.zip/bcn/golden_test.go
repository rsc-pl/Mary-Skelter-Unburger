package bcn

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"testing"
)

// goldenEncodeHashes freezes encoder output byte-exactly across formats and quality levels.
// Output-preserving optimizations must keep these hashes;
// deliberate metric changes regenerate them via BCN_GOLDEN_PRINT=1
// together with a PSNR comparison documented in the change.
var goldenEncodeHashes = map[string]string{
	"BC1/opaque/q1":       "645bebcb02564fba",
	"BC1/opaque/q2":       "49022b4011bc1ddd",
	"BC1/opaque/q3":       "122400b9c696028a",
	"BC1/opaque/q4":       "d765ea758656b179",
	"BC1/opaque/q5":       "04abe32437d913d3",
	"BC1/opaque/q6":       "086c9a5a46b258b7",
	"BC1/opaque/q7":       "be3fb6ee9f0e8706",
	"BC1/opaque/q8":       "3f5d21d232f1592f",
	"BC1/opaque/q9":       "13cdb6ac1be82601",
	"BC1/opaque/q10":      "c29052c9f02e1bcf",
	"BC1/translucent/q1":  "0f2d56329e5adbaa",
	"BC1/translucent/q2":  "f2cdc3180f61b389",
	"BC1/translucent/q3":  "052c7b2e6d349c03",
	"BC1/translucent/q4":  "59fc241c2e771f12",
	"BC1/translucent/q5":  "90f13979ea874bdf",
	"BC1/translucent/q6":  "1d064a543929425c",
	"BC1/translucent/q7":  "b101a8ec39975c66",
	"BC1/translucent/q8":  "7cafcda90ce77b87",
	"BC1/translucent/q9":  "0632379ec630dff2",
	"BC1/translucent/q10": "aec3701cdf5677ff",
	"BC2/translucent/q1":  "b0b375a13743fd27",
	"BC2/translucent/q2":  "c1b8b0061a98f19e",
	"BC2/translucent/q3":  "e8bb7e07a2d0d946",
	"BC2/translucent/q4":  "475793c0dfc0b713",
	"BC2/translucent/q5":  "f585fe1ef5d219f7",
	"BC2/translucent/q6":  "a9d917310f873da0",
	"BC2/translucent/q7":  "40f10292f8497676",
	"BC2/translucent/q8":  "a9cfa8e20b8418d2",
	"BC2/translucent/q9":  "ab9643b36f91f24b",
	"BC2/translucent/q10": "8e77c95ad95b244a",
	"BC3/translucent/q1":  "c2af7a143698e692",
	"BC3/translucent/q2":  "359843aeb5d1cd4c",
	"BC3/translucent/q3":  "d2f61ad341876a40",
	"BC3/translucent/q4":  "727da9ef9495f675",
	"BC3/translucent/q5":  "e7963ee34b751b03",
	"BC3/translucent/q6":  "70b3b8b6f8f29e15",
	"BC3/translucent/q7":  "7272b3ab002aca55",
	"BC3/translucent/q8":  "8863e14a635c2798",
	"BC3/translucent/q9":  "35f00ab0bb2149d5",
	"BC3/translucent/q10": "123cfc9ff11bde4c",
	"BC3/nohq/q1":         "8b732676827b3617",
	"BC3/nohq/q2":         "8372d844da2ec237",
	"BC3/nohq/q3":         "fbde30eb8d508e1b",
	"BC3/nohq/q4":         "53298e682d2921f3",
	"BC3/nohq/q5":         "820c18adeb4c8df8",
	"BC3/nohq/q6":         "a1de3e30e4a22a2a",
	"BC3/nohq/q7":         "53af96172ee42de9",
	"BC3/nohq/q8":         "e9505a3f2731bd7a",
	"BC3/nohq/q9":         "016eb16aad2b1565",
	"BC3/nohq/q10":        "016eb16aad2b1565",
	"BC4/opaque/q1":       "b63e66185a881fd6",
	"BC4/opaque/q2":       "4f4e3f564d05246c",
	"BC4/opaque/q3":       "4f4e3f564d05246c",
	"BC4/opaque/q4":       "4f4e3f564d05246c",
	"BC4/opaque/q5":       "4f4e3f564d05246c",
	"BC4/opaque/q6":       "4f4e3f564d05246c",
	"BC4/opaque/q7":       "4f4e3f564d05246c",
	"BC4/opaque/q8":       "778a4651318576fe",
	"BC4/opaque/q9":       "778a4651318576fe",
	"BC4/opaque/q10":      "778a4651318576fe",
	"BC5/opaque/q1":       "51bfd7a4de1a48c9",
	"BC5/opaque/q2":       "b735707000d9e609",
	"BC5/opaque/q3":       "b735707000d9e609",
	"BC5/opaque/q4":       "b735707000d9e609",
	"BC5/opaque/q5":       "b735707000d9e609",
	"BC5/opaque/q6":       "b735707000d9e609",
	"BC5/opaque/q7":       "b735707000d9e609",
	"BC5/opaque/q8":       "330bcfc40f2875fc",
	"BC5/opaque/q9":       "330bcfc40f2875fc",
	"BC5/opaque/q10":      "330bcfc40f2875fc",
	"BC4S/opaque/q1":      "0a1fcccb8b9c1fa5",
	"BC4S/opaque/q2":      "9a48e581600f0938",
	"BC4S/opaque/q3":      "66f98ddd67d95c1b",
	"BC4S/opaque/q4":      "66f98ddd67d95c1b",
	"BC4S/opaque/q5":      "66f98ddd67d95c1b",
	"BC4S/opaque/q6":      "66f98ddd67d95c1b",
	"BC4S/opaque/q7":      "66f98ddd67d95c1b",
	"BC4S/opaque/q8":      "66f98ddd67d95c1b",
	"BC4S/opaque/q9":      "66f98ddd67d95c1b",
	"BC4S/opaque/q10":     "66f98ddd67d95c1b",
	"BC5S/opaque/q1":      "0c714ffcf6660503",
	"BC5S/opaque/q2":      "15a74ff51615f22b",
	"BC5S/opaque/q3":      "866fd5f85ab1b615",
	"BC5S/opaque/q4":      "866fd5f85ab1b615",
	"BC5S/opaque/q5":      "866fd5f85ab1b615",
	"BC5S/opaque/q6":      "866fd5f85ab1b615",
	"BC5S/opaque/q7":      "866fd5f85ab1b615",
	"BC5S/opaque/q8":      "866fd5f85ab1b615",
	"BC5S/opaque/q9":      "866fd5f85ab1b615",
	"BC5S/opaque/q10":     "866fd5f85ab1b615",
	"BC7/opaque/q1":       "676bc14c0e70df41",
	"BC7/opaque/q2":       "a8495ee1c31144c6",
	"BC7/opaque/q3":       "a8495ee1c31144c6",
	"BC7/opaque/q4":       "1b967653bb24b65a",
	"BC7/opaque/q5":       "1b967653bb24b65a",
	"BC7/opaque/q6":       "1b967653bb24b65a",
	"BC7/opaque/q7":       "25855d0290901ffb",
	"BC7/opaque/q8":       "25855d0290901ffb",
	"BC7/opaque/q9":       "f6d2c255f5ac6d64",
	"BC7/opaque/q10":      "f1e2fe57dbf63121",
	"BC7/translucent/q1":  "80f1cd8d9ca86319",
	"BC7/translucent/q2":  "f4c2e8252dbe4fc8",
	"BC7/translucent/q3":  "f4c2e8252dbe4fc8",
	"BC7/translucent/q4":  "004f46b918859a66",
	"BC7/translucent/q5":  "004f46b918859a66",
	"BC7/translucent/q6":  "004f46b918859a66",
	"BC7/translucent/q7":  "a092a73d21ea9d17",
	"BC7/translucent/q8":  "a092a73d21ea9d17",
	"BC7/translucent/q9":  "bdd359b7d3e6f0a9",
	"BC7/translucent/q10": "2020711052772849",
	"BC6HU/UF16/q1":       "dd7dc80381029671",
	"BC6HU/UF16/q2":       "e509f7ee6e05549f",
	"BC6HU/UF16/q3":       "e509f7ee6e05549f",
	"BC6HU/UF16/q4":       "d6155550e1dc8a27",
	"BC6HU/UF16/q5":       "d6155550e1dc8a27",
	"BC6HU/UF16/q6":       "d6155550e1dc8a27",
	"BC6HU/UF16/q7":       "d6155550e1dc8a27",
	"BC6HU/UF16/q8":       "b6b179bbd0a84dfb",
	"BC6HU/UF16/q9":       "b6b179bbd0a84dfb",
	"BC6HU/UF16/q10":      "b6b179bbd0a84dfb",
	"BC6HS/SF16/q1":       "3beb645d3bbbe7c6",
	"BC6HS/SF16/q2":       "ab112c70855ed726",
	"BC6HS/SF16/q3":       "ab112c70855ed726",
	"BC6HS/SF16/q4":       "d4ac8130bda6692a",
	"BC6HS/SF16/q5":       "d4ac8130bda6692a",
	"BC6HS/SF16/q6":       "d4ac8130bda6692a",
	"BC6HS/SF16/q7":       "d4ac8130bda6692a",
	"BC6HS/SF16/q8":       "a1cc3f7a98445ee8",
	"BC6HS/SF16/q9":       "a1cc3f7a98445ee8",
	"BC6HS/SF16/q10":      "a1cc3f7a98445ee8",
}

// goldenImage returns a deterministic 64x64 test image per scenario.
func goldenImage(scenario string) []byte {
	const w, h = 64, 64
	rgba := make([]byte, w*h*4)
	idx := 0

	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			switch scenario {
			case "opaque":
				rgba[idx+0] = uint8((x*13 + y*7 + 11) & 0xFF)
				rgba[idx+1] = uint8((x*3 + y*11 + 29) & 0xFF)
				rgba[idx+2] = uint8((x*17 + y*5 + 71) & 0xFF)
				rgba[idx+3] = 255

			case "translucent":
				rgba[idx+0] = uint8((x*13 + y*7 + 11) & 0xFF)
				rgba[idx+1] = uint8((x*3 + y*11 + 29) & 0xFF)
				rgba[idx+2] = uint8((x*17 + y*5 + 71) & 0xFF)
				rgba[idx+3] = uint8((x*5 + y*9 + 101) & 0xFF)

			case "nohq":
				// Constant red channel: triggers BalancedRGBWeights path.
				rgba[idx+0] = 0
				rgba[idx+1] = uint8((x*3 + y*11 + 29) & 0xFF)
				rgba[idx+2] = uint8((x*17 + y*5 + 71) & 0xFF)
				rgba[idx+3] = uint8((x*5 + y*9 + 101) & 0xFF)
			}
			idx += 4
		}
	}

	return rgba
}

func goldenCases() []struct {
	name     string
	format   Format
	scenario string
	quality  int
} {
	formats := []struct {
		format   Format
		scenario string
	}{
		{FormatBC1, "opaque"},
		{FormatBC1, "translucent"},
		{FormatBC2, "translucent"},
		{FormatBC3, "translucent"},
		{FormatBC3, "nohq"},
		{FormatBC4, "opaque"},
		{FormatBC5, "opaque"},
		{FormatBC4S, "opaque"},
		{FormatBC5S, "opaque"},
		{FormatBC7, "opaque"},
		{FormatBC7, "translucent"},
		{FormatBC6HU, "UF16"},
		{FormatBC6HS, "SF16"},
	}

	var cases []struct {
		name     string
		format   Format
		scenario string
		quality  int
	}

	for _, f := range formats {
		for q := 1; q <= 10; q++ {
			cases = append(cases, struct {
				name     string
				format   Format
				scenario string
				quality  int
			}{
				name:     fmt.Sprintf("%s/%s/q%d", f.format, f.scenario, q),
				format:   f.format,
				scenario: f.scenario,
				quality:  q,
			})
		}
	}

	return cases
}

func goldenHash(t *testing.T, format Format, scenario string, quality int) string {
	t.Helper()
	opts := &EncodeOptions{QualityLevel: quality, AlphaThreshold: 128, Workers: 1}

	if format == FormatBC6HU || format == FormatBC6HS {
		signed := format == FormatBC6HS
		src := goldenHDRImage()
		encoded, err := EncodeBC6HWithOptions(src, 64, 64, signed, opts)
		if err != nil {
			t.Fatalf("encode %s/q%d: %v", format, quality, err)
		}
		decoded, err := DecodeBC6H(encoded, 64, 64, signed)
		if err != nil {
			t.Fatalf("decode %s/q%d: %v", format, quality, err)
		}
		h := sha256.New()
		h.Write(encoded)
		for _, v := range decoded {
			h.Write([]byte{byte(v), byte(v >> 8)})
		}
		return hex.EncodeToString(h.Sum(nil)[:8])
	}

	rgba := goldenImage(scenario)
	encoded, err := encodeBlocksWithOptions(rgba, 64, 64, format, opts)
	if err != nil {
		t.Fatalf("encode %s/%s/q%d: %v", format, scenario, quality, err)
	}

	decoded, err := decodeBlocksWithOptions(encoded, 64, 64, format, &DecodeOptions{Workers: 1})
	if err != nil {
		t.Fatalf("decode %s/%s/q%d: %v", format, scenario, quality, err)
	}

	sum := sha256.Sum256(append(encoded, decoded...))
	return hex.EncodeToString(sum[:8])
}

// TestGoldenEncodeOutput compares encoder+decoder output hashes with the frozen reference.
// Run with BCN_GOLDEN_PRINT=1 to print a fresh map literal.
func TestGoldenEncodeOutput(t *testing.T) {
	if os.Getenv("BCN_GOLDEN_PRINT") != "" {
		for _, c := range goldenCases() {
			fmt.Printf("\t%q: %q,\n", c.name, goldenHash(t, c.format, c.scenario, c.quality))
		}
		t.Skip("printed golden hashes")
	}

	if len(goldenEncodeHashes) == 0 {
		t.Skip("golden hashes not recorded yet")
	}

	for _, c := range goldenCases() {
		got := goldenHash(t, c.format, c.scenario, c.quality)
		want, ok := goldenEncodeHashes[c.name]
		if !ok {
			t.Errorf("%s: no golden hash recorded", c.name)
			continue
		}
		if got != want {
			t.Errorf("%s: output hash %s, want %s", c.name, got, want)
		}
	}
}
