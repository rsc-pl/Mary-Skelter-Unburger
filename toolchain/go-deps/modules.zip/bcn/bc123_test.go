package bcn

import (
	"bytes"
	"image"
	"image/color"
	"testing"
)

func TestBC1SolidBlock(t *testing.T) {
	c := color.NRGBA{R: 248, G: 252, B: 248, A: 255}
	img := SolidImage(4, 4, c)
	data, _, _, err := EncodeImage(img, FormatBC1)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	decoded, err := DecodeImage(data, 4, 4, FormatBC1)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	want := rgba8{c.R, c.G, c.B, c.A}
	for i := 0; i < len(decoded.Pix); i += 4 {
		got := rgba8{decoded.Pix[i], decoded.Pix[i+1], decoded.Pix[i+2], decoded.Pix[i+3]}
		if absDiffU8(got.r, want.r) > 12 || absDiffU8(got.g, want.g) > 12 || absDiffU8(got.b, want.b) > 12 || got.a != want.a {
			t.Fatalf("pixel mismatch: got=%v want=%v", got, want)
		}
	}
}

func TestBC2AlphaQuantization(t *testing.T) {
	img := SolidImage(4, 4, color.NRGBA{R: 100, G: 150, B: 200, A: 0})
	for i := 0; i < 16; i++ {
		img.Pix[i*4+3] = uint8(i * 17)
	}
	data, _, _, err := EncodeImage(img, FormatBC2)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	decoded, err := DecodeImage(data, 4, 4, FormatBC2)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	for i := 0; i < 16; i++ {
		orig := img.Pix[i*4+3]
		want := uint8((int(orig)+8)/17) * 17
		got := decoded.Pix[i*4+3]
		if got != want {
			t.Fatalf("alpha mismatch at %d: got=%d want=%d", i, got, want)
		}
	}
}

func TestBC3AlphaConstant(t *testing.T) {
	img := SolidImage(4, 4, color.NRGBA{R: 10, G: 20, B: 30, A: 200})
	data, _, _, err := EncodeImage(img, FormatBC3)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	decoded, err := DecodeImage(data, 4, 4, FormatBC3)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	for i := 0; i < 16; i++ {
		got := decoded.Pix[i*4+3]
		if got != 200 {
			t.Fatalf("alpha mismatch: got=%d want=200", got)
		}
	}
}

// TestBC3NohqStyle verifies that BC3 preserves B when R is constant (nohq normal map case).
func TestBC3NohqStyle(t *testing.T) {
	// One block: R=0, G and B varying so min/max B should be in the palette.
	img := image.NewNRGBA(image.Rect(0, 0, 4, 4))
	for i := 0; i < 16; i++ {
		img.Pix[i*4+0] = 0
		img.Pix[i*4+1] = uint8(i * 17)
		img.Pix[i*4+2] = uint8(255 - i*17)
		img.Pix[i*4+3] = 255
	}
	opts := &EncodeOptions{QualityLevel: QualityLevelFast}
	data, _, _, err := EncodeImageWithOptions(img, FormatBC3, opts)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	decoded, err := DecodeImage(data, 4, 4, FormatBC3)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	// Input had B from 255 down to 0; decoded block must have non-zero B somewhere.
	maxB := uint8(0)
	for i := 0; i < 16; i++ {
		b := decoded.Pix[i*4+2]
		if b > maxB {
			maxB = b
		}
	}
	if maxB == 0 {
		t.Fatalf("BC3 nohq-style roundtrip: B channel is all zero after decode (input had varying B)")
	}
}

// TestBC3NohqStyleMultiBlock verifies that BC3 with QualityLevelBest preserves B for multi-block nohq-style (R=0).
func TestBC3NohqStyleMultiBlock(t *testing.T) {
	const size = 16
	img := image.NewNRGBA(image.Rect(0, 0, size, size))
	for y := 0; y < size; y++ {
		for x := 0; x < size; x++ {
			i := y*size + x
			img.Pix[i*4+0] = 0
			img.Pix[i*4+1] = uint8((x * 255) / (size - 1))
			img.Pix[i*4+2] = uint8((y * 255) / (size - 1))
			img.Pix[i*4+3] = 255
		}
	}
	opts := &EncodeOptions{QualityLevel: QualityLevelBest}
	data, w, h, err := EncodeImageWithOptions(img, FormatBC3, opts)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	if w != size || h != size {
		t.Fatalf("encode size: got %dx%d", w, h)
	}
	decoded, err := DecodeImage(data, size, size, FormatBC3)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	maxB := uint8(0)
	for i := 0; i < size*size*4; i += 4 {
		if decoded.Pix[i+2] > maxB {
			maxB = decoded.Pix[i+2]
		}
	}
	if maxB == 0 {
		t.Fatalf("BC3 nohq-style multi-block (QualityLevelBest): B channel is all zero after decode")
	}
}

func TestDDSRoundTrip(t *testing.T) {
	img := SolidImage(8, 8, color.NRGBA{R: 180, G: 60, B: 220, A: 255})
	ds, err := EncodeDDS(img, FormatBC1)
	if err != nil {
		t.Fatalf("encode dds: %v", err)
	}
	buf := &bytes.Buffer{}
	if err := ds.Write(buf); err != nil {
		t.Fatalf("write dds: %v", err)
	}
	read, err := ReadDDS(bytes.NewReader(buf.Bytes()))
	if err != nil {
		t.Fatalf("read dds: %v", err)
	}
	if read.Width != 8 || read.Height != 8 || read.Format != FormatBC1 {
		t.Fatalf("dds header mismatch")
	}
	if len(read.Faces) != 1 || len(read.Faces[0].Mipmaps) != 1 {
		t.Fatalf("expected 1 mipmap")
	}
	if len(read.Faces[0].Mipmaps[0]) != len(ds.Faces[0].Mipmaps[0]) {
		t.Fatalf("mipmap size mismatch")
	}
}

func TestDDSCubemapMipmaps(t *testing.T) {
	images := []image.Image{
		SolidImage(8, 8, color.NRGBA{R: 255, G: 0, B: 0, A: 255}),
		SolidImage(8, 8, color.NRGBA{R: 0, G: 255, B: 0, A: 255}),
		SolidImage(8, 8, color.NRGBA{R: 0, G: 0, B: 255, A: 255}),
		SolidImage(8, 8, color.NRGBA{R: 255, G: 255, B: 0, A: 255}),
		SolidImage(8, 8, color.NRGBA{R: 255, G: 0, B: 255, A: 255}),
		SolidImage(8, 8, color.NRGBA{R: 0, G: 255, B: 255, A: 255}),
	}
	opts := &EncodeOptions{GenerateMipmaps: true, QualityLevel: QualityLevelFast}
	ds, err := EncodeDDSWithOptions(images, FormatBC1, opts)
	if err != nil {
		t.Fatalf("encode cubemap: %v", err)
	}
	if len(ds.Faces) != 6 {
		t.Fatalf("expected 6 faces")
	}
	if len(ds.Faces[0].Mipmaps) < 2 {
		t.Fatalf("expected mipmaps")
	}
	buf := &bytes.Buffer{}
	if err := ds.Write(buf); err != nil {
		t.Fatalf("write dds: %v", err)
	}
	read, err := ReadDDS(bytes.NewReader(buf.Bytes()))
	if err != nil {
		t.Fatalf("read dds: %v", err)
	}
	if !read.IsCubemap() {
		t.Fatalf("expected cubemap")
	}
	if len(read.Faces[0].Mipmaps) != len(ds.Faces[0].Mipmaps) {
		t.Fatalf("mipmap count mismatch")
	}
}

func absDiffU8(a, b uint8) uint8 {
	if a > b {
		return a - b
	}
	return b - a
}
