// SPDX-License-Identifier: MIT
// Copyright (c) 2026 WoozyMasta
// Source: github.com/woozymasta/bcn

/*
Package bcn provides BCn/DXT block compression encode/decode and container I/O.

The package focuses on practical texture workflows:
  - Encode/decode BC1/DXT1, BC2/DXT3, BC3/DXT5,
    BC4/BC5 (UNORM and SNORM), BC6H/BPTC-HDR, BC7/BPTC
  - Read/write DDS and KTX v1 containers
  - Optional mipmap generation with sRGB-aware downscaling

The core encode/decode APIs operate on NRGBA byte layout (R,G,B,A per pixel).
BC6H is the exception: its API uses []uint16 (or []float32) RGB half-float input,
via EncodeBC6H / DecodeBC6H and their variants.
For best results, ensure inputs are in the expected color space (typically sRGB)
and pick an appropriate QualityLevel in EncodeOptions.

DDS BGRA pixels are converted to RGBA on decode.
Uncompressed DDS and KTX support RGBA, BGRA, alpha-only A8, R8/RG8 (UNORM and SNORM),
RGB10A2, RGB565, RGBA5551, RGBA4444, RGB8, and BGR8;
DDS additionally supports BGRX8.
*/
package bcn
